const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.static(path.join(__dirname, 'public')));

// Kinopoisk Unofficial / Alloha / Videocdn / Kodik Integration
app.get('/api/search', async (req, res) => {
  const query = (req.query.q || '').trim();
  
  if (!query) {
    return res.json([
      {
        id: '1252447',
        title: 'Вышка (Fall, 2022)',
        year: 2022,
        poster: 'https://kinopoiskapiuncensored.ru/posters/1252447.jpg',
        type: 'iframe',
        url: 'https://22447.sv288.org/embed/movie/1252447'
      },
      {
        id: '435',
        title: 'Зеленая миля (1999)',
        year: 1999,
        poster: 'https://kinopoiskapiuncensored.ru/posters/435.jpg',
        type: 'iframe',
        url: 'https://22447.sv288.org/embed/movie/435'
      },
      {
        id: 'demo-mp4',
        title: 'Тестовый MP4 (Big Buck Bunny)',
        year: 2008,
        poster: 'https://upload.wikimedia.org/wikipedia/commons/c/c5/Big_buck_bunny_poster_big.jpg',
        type: 'mp4',
        url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4'
      }
    ]);
  }

  // Extract ID if Kinopoisk URL passed
  const kpMatch = query.match(/(?:film\/|movie\/)(\d+)|(\d{4,8})/);
  const kpId = kpMatch ? (kpMatch[1] || kpMatch[2]) : null;

  try {
    // Search using Kinopoisk Dev / Alloha / Kodik public mirror API
    const searchUrl = kpId 
      ? `https://kinopoiskapiuncensored.ru/api/search?kp=${kpId}` 
      : `https://kinopoiskapiuncensored.ru/api/search?title=${encodeURIComponent(query)}`;

    const response = await fetch(searchUrl);
    if (response.ok) {
      const data = await response.json();
      if (Array.isArray(data) && data.length > 0) {
        const results = data.map(item => ({
          id: item.kinopoisk_id || item.id || String(Math.random()),
          title: `${item.name_ru || item.title || query} (${item.year || ''})`,
          year: item.year || '',
          poster: item.poster || 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=300&q=80',
          type: 'iframe',
          url: item.iframe_url || `https://22447.sv288.org/embed/movie/${item.kinopoisk_id || item.id || kpId}`
        }));
        return res.json(results);
      }
    }
  } catch (err) {
    console.log('Online API unreachable, using reliable player mirrors', err);
  }

  // Fallback to active multi-player mirrors (Kinobox / Alloha / Lumex embed)
  const targetId = kpId || '1252447'; // Default to Fall (Вышка) or requested ID
  res.json([
    {
      id: targetId,
      title: `${query} (Онлайн Плеер #1 - Kinobox)`,
      year: '2024',
      poster: 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=300&q=80',
      type: 'iframe',
      url: `https://kinobox.in/kinopoisk/${targetId}`
    },
    {
      id: targetId + '-mirror2',
      title: `${query} (Онлайн Плеер #2 - Alloha)`,
      year: '2024',
      poster: 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=300&q=80',
      type: 'iframe',
      url: `https://22447.sv288.org/embed/movie/${targetId}`
    }
  ]);
});

// Store room state
const rooms = {};

io.on('connection', (socket) => {
  let currentRoom = null;
  let username = 'Гость';

  socket.on('join-room', ({ roomId, name }) => {
    if (!roomId) return;
    currentRoom = roomId;
    username = name || 'Гость';

    socket.join(roomId);

    if (!rooms[roomId]) {
      rooms[roomId] = {
        videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
        videoType: 'mp4',
        currentTime: 0,
        isPlaying: false,
        lastUpdated: Date.now(),
        users: {}
      };
    }

    rooms[roomId].users[socket.id] = username;

    socket.emit('room-state', {
      videoUrl: rooms[roomId].videoUrl,
      videoType: rooms[roomId].videoType,
      currentTime: rooms[roomId].isPlaying 
        ? rooms[roomId].currentTime + (Date.now() - rooms[roomId].lastUpdated) / 1000 
        : rooms[roomId].currentTime,
      isPlaying: rooms[roomId].isPlaying,
      users: Object.values(rooms[roomId].users)
    });

    io.to(roomId).emit('update-users', Object.values(rooms[roomId].users));
    io.to(roomId).emit('chat-message', {
      user: 'Система',
      text: `${username} присоединился к комнате`,
      isSystem: true
    });
  });

  socket.on('change-video', ({ videoUrl, videoType, title }) => {
    if (!currentRoom || !rooms[currentRoom]) return;
    
    const isIframe = videoType === 'iframe' || videoUrl.includes('iframe') || videoUrl.includes('embed') || videoUrl.includes('kinobox') || !videoUrl.match(/\.(mp4|webm|ogg)$/i);
    
    rooms[currentRoom].videoUrl = videoUrl;
    rooms[currentRoom].videoType = isIframe ? 'iframe' : 'mp4';
    rooms[currentRoom].currentTime = 0;
    rooms[currentRoom].isPlaying = false;
    rooms[currentRoom].lastUpdated = Date.now();

    io.to(currentRoom).emit('video-changed', { 
      videoUrl: rooms[currentRoom].videoUrl,
      videoType: rooms[currentRoom].videoType
    });

    io.to(currentRoom).emit('chat-message', {
      user: 'Система',
      text: `${username} включил: ${title || videoUrl}`,
      isSystem: true
    });
  });

  socket.on('player-action', ({ action, time }) => {
    if (!currentRoom || !rooms[currentRoom]) return;

    if (action === 'play') {
      rooms[currentRoom].isPlaying = true;
      rooms[currentRoom].currentTime = time;
      rooms[currentRoom].lastUpdated = Date.now();
      socket.to(currentRoom).emit('sync-player', { action: 'play', time });
    } else if (action === 'pause') {
      rooms[currentRoom].isPlaying = false;
      rooms[currentRoom].currentTime = time;
      rooms[currentRoom].lastUpdated = Date.now();
      socket.to(currentRoom).emit('sync-player', { action: 'pause', time });
    } else if (action === 'seek') {
      rooms[currentRoom].currentTime = time;
      rooms[currentRoom].lastUpdated = Date.now();
      socket.to(currentRoom).emit('sync-player', { action: 'seek', time });
    }
  });

  socket.on('send-message', (text) => {
    if (!currentRoom) return;
    io.to(currentRoom).emit('chat-message', {
      user: username,
      text: text,
      isSystem: false,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    });
  });

  socket.on('disconnect', () => {
    if (currentRoom && rooms[currentRoom]) {
      delete rooms[currentRoom].users[socket.id];
      io.to(currentRoom).emit('update-users', Object.values(rooms[currentRoom].users));
      io.to(currentRoom).emit('chat-message', {
        user: 'Система',
        text: `${username} покинул комнату`,
        isSystem: true
      });
      if (Object.keys(rooms[currentRoom].users).length === 0) {
        delete rooms[currentRoom];
      }
    }
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Сервер запущен на http://localhost:${PORT}`);
});
