const socket = io();

// DOM elements
const joinModal = document.getElementById('join-modal');
const appContainer = document.getElementById('app');
const usernameInput = document.getElementById('username-input');
const roomInput = document.getElementById('room-input');
const joinBtn = document.getElementById('join-btn');

const currentRoomName = document.getElementById('current-room-name');
const copyRoomBtn = document.getElementById('copy-room-btn');

const videoWrapper = document.getElementById('video-wrapper');
const videoPlayer = document.getElementById('video-player');
const iframePlayer = document.getElementById('iframe-player');
const fsBtn = document.getElementById('fs-btn');
const userCount = document.getElementById('user-count');
const onlineUsersList = document.getElementById('online-users-list');

const movieSearchInput = document.getElementById('movie-search-input');
const searchMovieBtn = document.getElementById('search-movie-btn');
const searchResultsDropdown = document.getElementById('search-results-dropdown');

const chatMessages = document.getElementById('chat-messages');
const chatForm = document.getElementById('chat-form');
const chatInput = document.getElementById('chat-input');

let isRemoteAction = false;
let currentRoom = '';

// Auto-fill room from URL params if present
const urlParams = new URLSearchParams(window.location.search);
const roomParam = urlParams.get('room');
if (roomParam) {
  roomInput.value = roomParam;
} else {
  roomInput.value = 'movie-' + Math.floor(1000 + Math.random() * 9000);
}

// Join Room Event
joinBtn.addEventListener('click', () => {
  const name = usernameInput.value.trim() || 'Зритель';
  const room = roomInput.value.trim();

  if (!room) return alert('Пожалуйста, введите название комнаты');

  currentRoom = room;
  currentRoomName.textContent = room;

  const newUrl = `${window.location.origin}${window.location.pathname}?room=${encodeURIComponent(room)}`;
  window.history.pushState({ path: newUrl }, '', newUrl);

  socket.emit('join-room', { roomId: room, name });

  joinModal.classList.add('hidden');
  appContainer.classList.remove('hidden');
});

// Copy Room Link
copyRoomBtn.addEventListener('click', () => {
  navigator.clipboard.writeText(window.location.href);
  alert('Ссылка на комнату скопирована!');
});

// Fullscreen Handler
if (fsBtn) {
  fsBtn.addEventListener('click', () => {
    if (!document.fullscreenElement && !document.webkitFullscreenElement) {
      if (videoWrapper.requestFullscreen) {
        videoWrapper.requestFullscreen();
      } else if (videoWrapper.webkitRequestFullscreen) {
        videoWrapper.webkitRequestFullscreen();
      }
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen();
      } else if (document.webkitExitFullscreen) {
        document.webkitExitFullscreen();
      }
    }
  });
}

// Movie Search Logic (Touch & Keyboard friendly for mobile)
searchMovieBtn.addEventListener('click', (e) => {
  e.preventDefault();
  performSearch();
});

movieSearchInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') {
    e.preventDefault();
    performSearch();
  }
});

function performSearch() {
  const query = movieSearchInput.value.trim();
  if (!query) return;

  // Touch device keyboard hide
  movieSearchInput.blur();

  if (query.startsWith('http') || query.includes('kinopoisk.ru')) {
    const kpIdMatch = query.match(/(?:film\/|movie\/)(\d+)|(\d{4,8})/);
    const kpId = kpIdMatch ? (kpIdMatch[1] || kpIdMatch[2]) : '1252447';
    const embedUrl = `https://kinobox.in/kinopoisk/${kpId}`;
    
    socket.emit('change-video', {
      videoUrl: embedUrl,
      videoType: 'iframe',
      title: 'Фильм с Кинопоиска'
    });
    movieSearchInput.value = '';
    searchResultsDropdown.classList.add('hidden');
    return;
  }

  fetch(`/api/search?q=${encodeURIComponent(query)}`)
    .then(res => res.json())
    .then(data => {
      renderSearchResults(data);
    })
    .catch(err => {
      console.error(err);
      alert('Ошибка при поиске фильма');
    });
}

function renderSearchResults(movies) {
  searchResultsDropdown.innerHTML = '';
  if (!movies || movies.length === 0) {
    searchResultsDropdown.classList.add('hidden');
    return;
  }

  movies.forEach(movie => {
    const item = document.createElement('div');
    item.classList.add('search-item');
    item.innerHTML = `
      <img src="${movie.poster}" alt="Poster" onerror="this.src='https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=300&q=80'">
      <div class="search-item-info">
        <div class="search-item-title">${escapeHtml(movie.title)}</div>
        <div class="search-item-year">${movie.year || ''} • Нажмите включить</div>
      </div>
    `;

    // Supporting both click and touchstart for mobile response
    const selectMovie = (e) => {
      e.preventDefault();
      socket.emit('change-video', {
        videoUrl: movie.url,
        videoType: movie.type,
        title: movie.title
      });
      searchResultsDropdown.classList.add('hidden');
      movieSearchInput.value = '';
    };

    item.addEventListener('click', selectMovie);
    searchResultsDropdown.appendChild(item);
  });

  searchResultsDropdown.classList.remove('hidden');
}

// Close dropdown when touching outside
document.addEventListener('touchstart', (e) => {
  if (!searchResultsDropdown.contains(e.target) && e.target !== movieSearchInput && e.target !== searchMovieBtn) {
    searchResultsDropdown.classList.add('hidden');
  }
});
document.addEventListener('click', (e) => {
  if (!searchResultsDropdown.contains(e.target) && e.target !== movieSearchInput && e.target !== searchMovieBtn) {
    searchResultsDropdown.classList.add('hidden');
  }
});

// Player Events
videoPlayer.addEventListener('play', () => {
  if (isRemoteAction) return;
  socket.emit('player-action', { action: 'play', time: videoPlayer.currentTime });
});

videoPlayer.addEventListener('pause', () => {
  if (isRemoteAction) return;
  socket.emit('player-action', { action: 'pause', time: videoPlayer.currentTime });
});

videoPlayer.addEventListener('seeked', () => {
  if (isRemoteAction) return;
  socket.emit('player-action', { action: 'seek', time: videoPlayer.currentTime });
});

// Chat Submit
chatForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const msg = chatInput.value.trim();
  if (msg) {
    socket.emit('send-message', msg);
    chatInput.value = '';
  }
});

// Socket.io Events
socket.on('room-state', (state) => {
  setVideoSource(state.videoUrl, state.videoType, state.currentTime, state.isPlaying);
  updateUsersList(state.users);
});

socket.on('video-changed', ({ videoUrl, videoType }) => {
  setVideoSource(videoUrl, videoType, 0, true);
});

function setVideoSource(url, type, currentTime = 0, autoPlay = false) {
  if (type === 'iframe' || url.includes('kinobox') || url.includes('embed') || !url.match(/\.(mp4|webm|ogg)$/i)) {
    videoPlayer.classList.add('hidden');
    iframePlayer.classList.remove('hidden');
    iframePlayer.src = url;
  } else {
    iframePlayer.classList.add('hidden');
    videoPlayer.classList.remove('hidden');
    videoPlayer.src = url;
    videoPlayer.currentTime = currentTime;
    if (autoPlay) {
      videoPlayer.play().catch(e => console.log('Autoplay blocked:', e));
    }
  }
}

socket.on('sync-player', ({ action, time }) => {
  if (iframePlayer.classList.contains('hidden')) {
    isRemoteAction = true;
    if (Math.abs(videoPlayer.currentTime - time) > 0.5) {
      videoPlayer.currentTime = time;
    }

    if (action === 'play') {
      videoPlayer.play().catch(e => console.log(e));
    } else if (action === 'pause') {
      videoPlayer.pause();
    }

    setTimeout(() => { isRemoteAction = false; }, 300);
  }
});

socket.on('update-users', (users) => {
  updateUsersList(users);
});

socket.on('chat-message', (data) => {
  const msgEl = document.createElement('div');
  msgEl.classList.add('chat-message');

  if (data.isSystem) {
    msgEl.classList.add('system');
    msgEl.textContent = data.text;
  } else {
    msgEl.innerHTML = `<span class="user">${escapeHtml(data.user)}:</span><span class="text">${escapeHtml(data.text)}</span><span class="time">${data.time}</span>`;
  }

  chatMessages.appendChild(msgEl);
  chatMessages.scrollTop = chatMessages.scrollHeight;
});

function updateUsersList(users) {
  userCount.textContent = users.length;
  onlineUsersList.innerHTML = '';
  users.forEach(u => {
    const chip = document.createElement('div');
    chip.classList.add('user-chip');
    chip.textContent = u;
    onlineUsersList.appendChild(chip);
  });
}

function escapeHtml(str) {
  return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
}
